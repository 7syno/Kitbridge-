import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mycompany.app',
  appName: 'My Android App',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    url: 'https://ais-dev-r35c5bi4by7vvbgdbaag4m-174983757590.europe-west2.run.app/'
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: true
  }
};

export default config;