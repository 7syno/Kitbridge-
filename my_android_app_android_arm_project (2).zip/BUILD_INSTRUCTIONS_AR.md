# كيفية تحويل هذا المشروع إلى ملف APK لأجهزة Android (ARM)

## الطريقة الأولى: عن طريق GitHub Actions (تلقائي وبدون برامج)
1. قم برفع كافة ملفات هذا المجلد إلى مستودع GitHub جديد.
2. انتقل إلى تبويب **Actions** في مستودع GitHub الخاص بك.
3. ستجد عمل **Build Android ARM APK** يتم تشغيله تلقائياً.
4. بعد انتهاء البناء (حوالي 2-3 دقائق)، اضغط على النتيجة وقم بتنزيل ملف الـ **APK (ARM64)** مباشرة إلى هاتفك!

---

## الطريقة الثانية: باستخدام Android Studio على جهازك
1. تأكد من تثبيت Node.js و Android Studio على جهازك.
2. افتح المجلد في Terminal ثم نفّذ الأوامر التالية:
   ```bash
   npm install
   npm run build
   npx cap add android
   npx cap open android
   ```
3. في برنامج Android Studio، اضغط على **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. ستجد ملف الـ APK النامج جاهز للتثبيت على هواتف أندرويد المعالجة بأرم (ARM64 / ARMv7).

---

## الطريقة الثالثة: باستخدام موقع PWABuilder (الأسرع خلال دقيقة)
1. افتح رابط تطبيقك المنشور على الويب.
2. انتقل إلى [https://www.pwabuilder.com](https://www.pwabuilder.com) وادخل رابط التطبيق.
3. اضغط على **Build Android Package** لتحصل على ملف APK جاهز فوراً.
